Hello,

Thank for purchasing and using Font by Keristyper.
get more font collection at kerismaker.com/product-category/font/


How to Enable OpenType Features in Word, Photoshop and Illustrator

https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

How to Using Special Characters

https://helpx.adobe.com/illustrator/using/special-characters.html